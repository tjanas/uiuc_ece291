// This may look like C code, but it is really -*- C++ -*-

#ifndef _Complex_h
#define _Complex_h

// Use the ANSI complex number template.
#include <complex>
typedef complex<double> Complex;

#endif
