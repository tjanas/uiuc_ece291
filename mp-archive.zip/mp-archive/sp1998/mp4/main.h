
// Header file for 3D Project  3DProj.H

// Constants
#define CELL_X_SIZE        64
#define CELL_Y_SIZE        64
#define CELL_X_SIZE_FP   6   // log base 2 of 64 (used for quick division)
#define CELL_Y_SIZE_FP   6
#define INTERSECTION_FOUND  1
#define PI                  3.14159265359
#define RAY_INCREMENT       0.003272492
// Table angle values
#define ANGLE_0     0
#define ANGLE_1     5
#define ANGLE_2     10
#define ANGLE_4     20
#define ANGLE_5     25
#define ANGLE_6     30
#define ANGLE_15    80
#define ANGLE_30    160
#define ANGLE_45    240
#define ANGLE_60    320
#define ANGLE_90    480
#define ANGLE_135   720
#define ANGLE_180   960
#define ANGLE_225   1200
#define ANGLE_270   1440
#define ANGLE_315   1680
#define ANGLE_360   1920

extern void far _InstKey(void);
extern void far _DeInstallKey(void);
extern void far _DrawStrip(int, int, int, int, int);
extern void far DrawStrip(int, int, int, int, int);
extern void far _ShowScreenBuffer();
extern void far _SetUpGameData(int);
extern void far _CalculateMovement();
extern void far _ProcessMovement();
extern int  far _WorldValue(int, int);

extern void far TestLoadPCX();
extern void far StripTesterDisp(int);
extern void far ModeText();
extern void far ModeGraph();
extern void far KeyTester();
extern void far SetUpKeyTester();
extern void far DisplayFrameRate();
extern int  far CheckDoor(int, int, int);
extern void far mp4xit();

extern unsigned char far ExitFlag;
extern unsigned int  far Player_X;
extern unsigned int  far Player_Y;
extern unsigned int  far view_angle;
extern unsigned int  far BackGrnd;
extern float far         tan_table[];
extern float far         inv_tan_table[];
extern float far         y_step[];
extern float far         x_step[];
extern float far         correction_table[];
extern float far         inv_cos_table[];
extern float far         inv_sin_table[];
