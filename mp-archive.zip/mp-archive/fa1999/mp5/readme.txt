Q: When does a person decide to become an engineer?
A: When they realizes they don't have the charisma to be a mortician.

Q: What do engineers use for birth control?
A: Their personalities.

Q: How can you tell an extroverted engineer?
A: When they talk to you, they looks at your shoes instead of their own.
 
Q: How do you drive an engineer completely insane?
A: Tie them to a chair, stand in front of them, and fold up a road map the wrong way.

Women marry men expecting to change them, and they never can.
Men marry women expecging them not to change, and they always do.
