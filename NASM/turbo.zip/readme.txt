Installation Instructions:

If using turbo.bat to set up environment:

Edit path assignment in turbo.bat to point to the directory where
these files are located.  turbo.bat needs to be run in every DOS
box where NASM is needed to be used.

To avoid running turbo.bat in every DOS box, edit the global
environment settings and add the directory where these files are to
the PATH.

