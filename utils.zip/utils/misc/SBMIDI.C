#include <stdio.h>
#include <dos.h>
#include "sb.h"

int Sb_Read_MIDI(void)
{
    writedac(MIDI_READ_POLL);

    while(!(inportb(DSP_DATA_AVAIL) & 0x80))
	 ;
    return inportb(DSP_READ_DATA);
}

void Sb_Write_MIDI(int data)
{
    writedac(MIDI_WRITE_POLL);
    writedac(data);
}
