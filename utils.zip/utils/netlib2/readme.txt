
NetLib: NetBIOS Library Calls
-----------------------------
  John Lockwood, lockwood@ipoint.vlsi.uiuc.edu
  Department of Electrical and Computer Engineering
  University of Illinois at Urbana/Champaign
  Version 1.2, March 1999

Purpose
-------
  General purpose ASM network library for sending
  Multicast datagrams over NetBIOS.


Manifest of files
-----------------
  README     : This file
  Netlib.asm : Network library routines
  MACROS.INC : Handy macros 
  LIB291.LIB : Standard ECE291 library functions
  NetEx.asm  : Example application
  Netex.out  : Expected output from example application
  Makefile   : Dependencies

Build Instructions
------------------
  * Build NETLIB.OBJ, NETEX.OBJ, and NETEX.EXE using 'nmake'

  * Run NETEX.EXE on a machine that has NetBIOS properly installed.
    Compare results to NETEX.OUT (they should match).

Writing your own programs with Netlib
-------------------------------------
  * Use NetEX.ASM as a reference for your application.

     - Change grp_name to a suitable *16-character* group name
       for *your* application.  Default value = 'ECE291LibTest$$$'

     - Change my_name to a suitable *16-character* user name
       for *your* application.  Be Sure to leave '00' in the string at
       byte locations [12-13] for dynamic allocation.
       Default Value = 'ECE291Tester00$$'.

  * Notice the following features of NetEX.ASM:

    - External declarations for NetLib Functions

      extrn NetInit:near
      extrn SendPacket:near
      extrn NetRelease:near
      extrn NetTest:Near
      extrn TXBuffer:byte
      extrn RXBuffer:byte

    - Callback function called 'netpost' which is invoked
      whenever a datagram arrives.  Because this routine
      is called from an interrupt, it must:

         * Preserve all registers
         * Avoid DOS and LIB291 calls

    - NetINIT called at start of program

    - SendPacket called w/AX = Length to transmit data

    - NetRelease called at end of program

  * For your own applications, edit NETLIB.ASM to use unique names


Known Bugs
----------
  * Extra packet received at end of transmission  

Questions/Problems
------------------
  * Read 'CBIS NetBIOS Programmer's Reference'
  * Be sure that your Machine has NetBIOS Services properly installed
  * Obtain newest version at: http://www.ece.uiuc.edu/~ece291/class-resources
  * Email author at: lockwood@ipoint.vlsi.uiuc.edu

Distribution
------------
  * Copyright 1996-1999, John Lockwood and Eric Gardiner, All rights reserved
  * Free and open distribution of this code is allowed (and encouraged)
    provided that credits remain intact and files remain together.
  * This code comes with no warranties, expressed or implied.

Revision History
----------------
  1.0 : First Release - April 20, 1997
  1.1 : Includes revised lib291.lib
  1.2 : Migrate grp_name and my_name out of Netlib (March 1999)

